# News App (Stage 1)

This app is a draft for a news app that shows news received from the Guardian API.

This app has been made for educational purposes as part of the Udacity Google Developer Scholarship Challenge 2017/18.